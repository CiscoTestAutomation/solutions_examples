
from genie.harness.main import gRun

def main(runtime):
    gRun(runtime = runtime)
